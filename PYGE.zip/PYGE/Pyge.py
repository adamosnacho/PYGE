import pygame as pg
        
def Init(screenSize):
    pg.init()
    return pg.display.set_mode(screenSize)

def Key(Key):
    keys=pg.key.get_pressed()
    if keys[Key]:return True
    else:return False


def RUN():
    pg.display.flip()
    for event in pg.event.get():
        if event.type == pg.QUIT:
            return False
    return True





components = ['Render','Rigidbody','Collider']
class obj:
    def __init__(self,scr):
        self.scr = scr
        self.cmp = []


    def updObj(self):
        if 'Render' in self.cmp:self.render()
        if 'Collider' in self.cmp:self.collider()

    # renderer
    def render(self):
        try:
            self.renderSf.fill(self.renderColor)
        except:pass

        self.scr.blit(self.renderSf,self.renderRect)

    def renderStart(self,setup):
        self.renderColor = setup[1]
        self.renderSize = setup[0]
        self.renderSf = pg.Surface(self.renderSize)
        self.renderRect = self.renderSf.get_rect()
        self.updObj()


    # collider
    def collider(self):
        self.renderRect.colliderect()

        

    def colliderStart(self,setup):
        if 'Render' not in self.cmp:
            quit('No renderer attached to this object!')
        self.colliderRects = setup[0]
        self.updObj()

    def addComponent(self,component,setup):
        if component in components:
            self.cmp.append(component)
            if component == 'Render':
                self.renderStart(setup)
            if component == 'Collider':
                self.colliderStart(setup)
        else:quit('No such component like: '+ component)
